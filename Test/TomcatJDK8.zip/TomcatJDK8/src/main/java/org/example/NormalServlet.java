package org.example;

import org.apache.catalina.core.*;

import javax.servlet.*;
import javax.servlet.descriptor.JspConfigDescriptor;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.util.Collection;
import java.util.EventListener;

import static org.example.MemShell.MaliciousClass.addfilter1;

public class NormalServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
//        long pid = ProcessHandle.current().pid();
        // Print the PID
        // Create the upload directory if it does not exist

        // Respond to the user
        response.getWriter().println("HELLO WORLD! WELCOME TO MY TOMCAT");
//        response.getWriter().println("Current PID of this webserver: " + pid);
        response.getWriter().println("Current Class Path of this process: " + System.getProperty("java.class.path"));
        StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
        response.getWriter().println("\n=============================\nCurrent stack of Normal servlet: ");
        for (StackTraceElement element : stackTrace) {
            response.getWriter().println(element.toString());
        }

//            addfilter1(request, response);
            response.getWriter().println("\n=============================\nLISTING TOMCAT COMPONENTS");
        try {
            listComponents(getServletContext(),response);
        } catch (NoSuchFieldException e) {
            throw new RuntimeException(e);
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        }
//        Process p = new ProcessBuilder("cmd.exe", "/c calc.exe").start();

//        Testing.runCal();
    }
//
//    public static void addStackTrace(StackTraceElement[] stackTrace) {
//        if (stackTrace.length > 2) { // To avoid self-calls
//            StackTraceElement sensitiveMethod = stackTrace[1];
//            System.out.println("Sensitive method: " + sensitiveMethod.getClassName() + "." + sensitiveMethod.getMethodName());
//            StackTraceElement closestFrameworkMethod = null;
//            StackTraceElement jspGeneratedMethod = null;
//
//            // Iterate through stack trace to find the closest developer method, framework method, or JSP-generated method
//            for (int i = 2; i < stackTrace.length; i++) {
//                StackTraceElement currentElement = stackTrace[i];
//                String currentClassName = currentElement.getClassName();
//                if (!isFrameworkClass(currentClassName) && !isGeneratedJspClass(currentClassName)) {
//                    System.out.println("Closest developer method: " + currentElement.getClassName() + "." + currentElement.getMethodName());
////                    dumpCallerClass(currentElement.getClassName());
//                    return;
//                } else if (isGeneratedJspClass(currentClassName) && jspGeneratedMethod == null) {
//                    jspGeneratedMethod = currentElement;
//                } else if (isFrameworkClass(currentClassName) && closestFrameworkMethod == null) {
//                    closestFrameworkMethod = currentElement;
//                }
////                System.out.println("Framework or generated method: " + currentElement.getClassName() + "." + currentElement.getMethodName());
//
//            }
//
//            // If no developer method found, prioritize JSP-generated method over framework method
//            if (jspGeneratedMethod != null) {
//                System.out.println("JSP-generated method (potential malicious upload): " + jspGeneratedMethod.getClassName() + "." + jspGeneratedMethod.getMethodName());
//                dumpCallerClass(jspGeneratedMethod.getClassName());
//
//            } else if (closestFrameworkMethod != null) {
//                System.out.println("Closest framework method to developer code: " + closestFrameworkMethod.getClassName() + "." + closestFrameworkMethod.getMethodName());
////                dumpCallerClass(closestFrameworkMethod.getClassName());
//            }
//        }
//    }
//
//    private static boolean isFrameworkClass(String className) {
//        // Check if the class belongs to a known web framework or server package
//        return className.startsWith("org.apache.") || className.startsWith("javax.servlet.") || className.startsWith("java.");
//    }
//
//    private static boolean isGeneratedJspClass(String className) {
//        // Check if the class is a JSP-generated class (often contains 'jsp' or similar patterns)
//        return className.contains("_jsp") || className.contains("$jsp");
//    }
//
//    private static void dumpCallerClass(String callerClassName) {
//        try {
//            ClassPool classPool = ClassPool.getDefault();
//            String normalizedClassName = callerClassName.replaceAll("\\$\\d+", "");
//            CtClass callerClass = classPool.get(normalizedClassName);
//            saveBytecodeToFile(callerClass, callerClassName);
//        } catch (NotFoundException | IOException e) {
//            e.printStackTrace();
//        } catch (CannotCompileException e) {
//            throw new RuntimeException(e);
//        }
//    }
//
//    private static void saveBytecodeToFile(CtClass ctClass, String className) throws IOException, CannotCompileException {
//        String fileName = className.replace('.', '_') + ".class";
//        File file = new File("D:\\Download" + fileName);
//        try (FileOutputStream outputStream = new FileOutputStream(file)) {
//            outputStream.write(ctClass.toBytecode());
//            System.out.println("Bytecode saved for class: " + className);
//        } catch (CannotCompileException | IOException e) {
//            throw new RuntimeException(e);
//        }
//    }

    public static void listComponents(ServletContext servletContext, HttpServletResponse response) throws IOException, NoSuchFieldException, IllegalAccessException {

        Field f = servletContext.getClass().getDeclaredField("context");
        f.setAccessible(true);
        ApplicationContext appCtx = (ApplicationContext) f.get(servletContext);

        f = appCtx.getClass().getDeclaredField("context");
        f.setAccessible(true);
        StandardContext standardCtx = (StandardContext) f.get(appCtx);

        response.getWriter().println("Listing Tomcat components:");

        // List Filters
        response.getWriter().println("\nFilters:");
        Collection<FilterRegistration> filters = (Collection<FilterRegistration>) servletContext.getFilterRegistrations().values();
        for (FilterRegistration filter : filters) {
            response.getWriter().println("- " + filter.getName() + " (" + filter.getClassName() + ")");
        }

        // List Servlets
        response.getWriter().println("\nServlets:");
        Collection<ServletRegistration> servlets = (Collection<ServletRegistration>) servletContext.getServletRegistrations().values();
        for (ServletRegistration servlet : servlets) {
            response.getWriter().println("- " + servlet.getName() + " (" + servlet.getClassName() + ")");
        }

        // List Listeners
        response.getWriter().println("\nListeners:");
//        EventListener[] listeners = (EventListener[]) standardCtx.getApplicationEventListeners();
//        for (EventListener listener : listeners) {
//            response.getWriter().println("- " + listener.getClass().getName());
//        }
        Object[] listenerObjects = (Object[]) servletContext.getAttribute("org.apache.catalina.core.ApplicationEventListeners");
        if (listenerObjects != null) {
            for (Object listener : listenerObjects) {
                if (listener instanceof EventListener) {
                    response.getWriter().println("- " + listener.getClass().getName());
                }
            }
        } else {
            response.getWriter().println("- No listeners found or unable to access listener information");
        }
        // List JSP config
        response.getWriter().println("\nJSP Config:");
        JspConfigDescriptor jspConfigDescriptor = servletContext.getJspConfigDescriptor();
        if (jspConfigDescriptor != null) {
            response.getWriter().println("- JSP Config: " + jspConfigDescriptor.toString());
        } else {
            response.getWriter().println("- No JSP Config found");
        }
    }
}
