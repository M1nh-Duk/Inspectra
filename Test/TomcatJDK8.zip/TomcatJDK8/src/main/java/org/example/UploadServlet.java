package org.example;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import java.io.File;
import java.io.IOException;

@MultipartConfig
public class UploadServlet extends HttpServlet {

    private static final String UPLOAD_DIRECTORY = "uploads";  // Folder for storing uploaded files

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
//        long pid = ProcessHandle.current().pid();
        // Print the PID
//        System.out.println("The PID of this JVM process is: " + pid);
        // Create the upload directory if it does not exist
        String uploadPath = getServletContext().getRealPath("") + File.separator + UPLOAD_DIRECTORY;
        File uploadDir = new File(uploadPath);
        if (!uploadDir.exists()) {
            uploadDir.mkdir();
        }

        // Process uploaded file
        Part filePart = request.getPart("file"); // Retrieves <input type="file" name="file">
        String fileName = filePart.getSubmittedFileName(); // Get file name

        // Write the file to the uploads directory
        filePart.write(uploadPath + File.separator + fileName);

        // Respond to the user
        response.getWriter().println("File " + fileName + " uploaded successfully.");
        response.getWriter().println("Upload path: " + uploadPath + File.separator + fileName);
    }
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
//        long pid = ProcessHandle.current().pid();
        // Print the PID
//        System.out.println("The PID of this JVM process is: " + pid);
        // Create the upload directory if it does not exist
        String uploadPath = getServletContext().getRealPath("") + File.separator + UPLOAD_DIRECTORY;
        File uploadDir = new File(uploadPath);
        if (!uploadDir.exists()) {
            uploadDir.mkdir();
        }

        // Process uploaded file
        Part filePart = request.getPart("file"); // Retrieves <input type="file" name="file">
        String fileName = filePart.getSubmittedFileName(); // Get file name

        // Write the file to the uploads directory
        filePart.write(uploadPath + File.separator + fileName);

        // Respond to the user
        response.getWriter().println("File " + fileName + " uploaded successfully.");
        response.getWriter().println("Upload path: " + uploadPath + File.separator + fileName);
    }
}
