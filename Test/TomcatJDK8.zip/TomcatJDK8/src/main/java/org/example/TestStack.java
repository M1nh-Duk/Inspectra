package org.example;

import java.util.ArrayList;
import java.util.List;

class TestStack {
    public static void main(String[] args) {
        String stackTraceString1 = "" +
                "java.base/java.lang.Thread.getStackTrace(Thread.java:1602)\n" +
                "org.apache.tomcat.util.descriptor.web.FilterDef.setFilterName(FilterDef.java:116)\n" +
                "org.example.Malicious.register(DefaultServlet.java:30)\n" +
                "org.example.Hakki.init(DefaultServlet.java:30)\n" +
                "org.example.Halo.init(DefaultServlet.java:30)\n" +
                "javax.servlet.http.HttpServlet.service(HttpServlet.java:529)\n" +
                "javax.servlet.http.HttpServlet.service(HttpServlet.java:623)\n" +
                "org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:199)\n" +
                "org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:144)\n" ;

        String stackTraceString2 = "" +
                "java.base/java.lang.Thread.getStackTrace(Thread.java:1602)\n" +
                "org.apache.tomcat.util.descriptor.web.FilterDef.setFilterName(FilterDef.java:116)\n" +
                "org.apache.jsp.uploads._1addFilter_jsp$2.setFilterName(_1addFilter_jsp.java:259)\n" +
                "org.apache.jsp.uploads._1addFilter_jsp._jspService(_1addFilter_jsp.java:266)\n" +
                "org.apache.jasper.runtime.HttpJspBase.service(HttpJspBase.java:67)\n" +
                "javax.servlet.http.HttpServlet.service(HttpServlet.java:529)\n" +
                "javax.servlet.http.HttpServlet.service(HttpServlet.java:623)\n" +
                "org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:199)\n" +
                "org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:144)\n" ;

        String stackTraceString3 = "" +
                "java.base/java.lang.Thread.getStackTrace(Thread.java:1602)\n" +
                "org.apache.tomcat.util.descriptor.web.FilterDef.setFilterName(FilterDef.java:116)\n" +
                "org.apache.tomcat.util.descriptor.web.FilterDef.setFilterName2(FilterDef.java:102)\n" +
                "org.example.Hakki.init(DefaultServlet.java:30)\n" +
                "org.example.Halo.init(DefaultServlet.java:30)\n" +
                "javax.servlet.http.HttpServlet.service(HttpServlet.java:529)\n" +
                "javax.servlet.http.HttpServlet.service(HttpServlet.java:623)\n" +
                "org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:199)\n" +
                "org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:144)\n" ;
        StackTraceElement[] stackTraceElements = parseStackTrace(stackTraceString3);
        addStackTrace(stackTraceElements);
    }

    public static void addStackTrace(StackTraceElement[] stackTrace) {
        if (stackTrace.length > 2) { // To avoid self-calls
            StackTraceElement sensitiveMethod = stackTrace[1];
            System.out.println("Sensitive method: " + sensitiveMethod.getClassName() + "." + sensitiveMethod.getMethodName());
            StackTraceElement malClass = stackTrace[2];
            String tempClassList = malClass.getClassName();
            // Iterate through stack trace to find the closest JSP-generated method, developer method, or framework method
            if (!isFrameworkClass(malClass.getClassName()) && !isGeneratedJspClass(malClass.getClassName())) {
                tempClassList += ",";
                int i = 3;
                while (i < stackTrace.length && !isFrameworkClass(stackTrace[i].getClassName())) {
//                    if (stackTrace)
                    tempClassList += stackTrace[i].getClassName() + ",";
                    i++;
                }
            }


            // If we found a JSP-generated method, consider it potentially malicious
            System.out.println("MALICIOUS CLASS: " + malClass.getClassName());
            System.out.println("Temp Class List: " + tempClassList);
        }
    }

    // Helper method to parse a stack trace string into StackTraceElement[]
    private static StackTraceElement[] parseStackTrace(String stackTraceString) {
        String[] lines = stackTraceString.trim().split("\n");
        List<StackTraceElement> stackTraceElements = new ArrayList<>();
        for (String line : lines) {
            line = line.trim();
            if (!line.isEmpty()) {
                String[] parts = line.split("\\(");
                String classAndMethod = parts[0].trim();
                String fileAndLine = parts[1].replace(")", "").trim();
                String[] classAndMethodParts = classAndMethod.split("\\.");
                String methodName = classAndMethodParts[classAndMethodParts.length - 1];
                String className = classAndMethod.substring(0, classAndMethod.lastIndexOf("." + methodName));
                String[] fileAndLineParts = fileAndLine.split(":");
                String fileName = fileAndLineParts[0];
                int lineNumber = Integer.parseInt(fileAndLineParts[1]);
                stackTraceElements.add(new StackTraceElement(className, methodName, fileName, lineNumber));
            }
        }
        return stackTraceElements.toArray(new StackTraceElement[0]);
    }

    private static boolean isFrameworkClass(String className) {
        // Check if the class belongs to a known web framework or server package (excluding Java core)
        return className.startsWith("org.apache.") || className.startsWith("org.springframework.") || className.startsWith("javax.servlet.");
    }

    private static boolean isGeneratedJspClass(String className) {
        // Check if the class is a JSP-generated class (often contains 'jsp' or similar patterns)
        return className.contains("_jsp") || className.contains("$jsp") || className.contains(".jsp");
    }

}